// script.js
document.querySelectorAll('.explore-btn, .explore-courses-btn, .search-btn').forEach(button => {
    button.addEventListener('click', () => {
      alert('Button clicked!');
    });
  });
  
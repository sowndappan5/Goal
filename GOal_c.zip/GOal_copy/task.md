## task.md

***I. Foundational Skills***
**1. Basic Programming (Python)**

### Day 1: Introduction to Python & Variables
## Topics: 
- What is Python? Why is it used in AR development?
- Setting up your Python environment.
- Variables, data types (integers, floats, strings, booleans).

🎯 Tasks:
✅ Watch a video on Python basics (30 min).
✅ Create a simple Python script that prints "Hello, world!" (10 min).
✅ Declare variables of different data types and print their values (10 min).
✅ Practice basic arithmetic operations in Python (10 min).
✅ Research the benefits of Python for AR development (5 min).


---

### Day 2: Control Structures (if/else, loops)
## Topics:
- Conditional statements (if, elif, else).
- Loops (for, while).
- Basic program flow control.

🎯 Tasks:  
✅ Watch a video on conditional statements in Python (20 min).
✅ Write a Python program that checks if a number is even or odd (15 min).
✅ Create a program using a for loop to print numbers 1-10 (10 min).
✅ Write a program using a while loop to count down from 10 to 0 (10 min).
✅ Research different types of loops and their use cases (5 min).


---

### Day 3: Functions and Procedures
## Topics:
- Defining and calling functions.
- Function arguments and return values.
- Modularizing code using functions.

🎯 Tasks:  
✅ Watch a video on functions in Python (25 min).
✅ Write a function to calculate the area of a rectangle (15 min).
✅ Write a function to calculate the factorial of a number (15 min).
✅ Create a program that uses multiple functions to solve a problem (10 min).
✅ Research the benefits of using functions in programming (5 min).


---

### Day 4: Introduction to Object-Oriented Programming (OOP)
## Topics:
- Classes and objects.
- Attributes and methods.
- Basic OOP concepts.

🎯 Tasks:  
✅ Watch a video on OOP in Python (30 min).
✅ Create a simple class representing a dog with attributes and methods (15 min).
✅ Extend the dog class to add new attributes and methods (15 min).
✅ Research different OOP principles (e.g., inheritance, polymorphism) (5 min).
✅ Try to create a simple game object with OOP principles (10 min).


---

### Day 5: Data Structures (Lists, Dictionaries)
## Topics:
- Lists: ordered, mutable sequences.
- Dictionaries: unordered key-value pairs.
- Using lists and dictionaries in Python.

🎯 Tasks:  
✅ Watch a video on lists and dictionaries in Python (25 min).
✅ Create a list of numbers and perform operations (e.g., sorting, appending) (10 min).
✅ Create a dictionary representing a person's information (10 min).
✅ Practice accessing and modifying elements in lists and dictionaries (10 min).
✅ Research other data structures available in Python (5 min).


---

### Day 6:  Practice Python Projects
## Topics:
- Applying learned concepts to small projects.
- Problem-solving and debugging.

🎯 Tasks:  
✅ Build a simple calculator program (20 min).
✅ Create a program that generates a random password (15 min).
✅ Develop a basic text-based game (20 min).
✅ Debug and improve your existing Python code (15 min).
✅ Explore online resources for Python coding challenges (5 min).


---

### Day 7: BLANK


---

### Day 8: Introduction to 3D Modeling Software (Blender)
## Topics:
- Interface overview of Blender.
- Creating basic 3D primitives (cube, sphere, cylinder).
- Navigation within the 3D viewport.

🎯 Tasks:
✅ Watch a Blender tutorial on interface navigation (20 min).
✅ Create a cube, sphere, and cylinder (10 min each).
✅ Experiment with scaling, rotation, and translation tools (15 min).
✅ Save your Blender file and render a simple image (10 min).
✅ Research basic Blender shortcuts (5 min).


---

### Day 9: Transformations & Modifiers
## Topics:
- Transforming objects (scale, rotate, translate).
- Using modifiers (e.g., array, mirror).
- Understanding object origins and pivots.

🎯 Tasks:
✅ Practice scaling, rotating, and translating objects precisely (15 min each).
✅ Use the array modifier to create a row of objects (15 min).
✅ Use the mirror modifier to create a symmetrical object (15 min).
✅ Experiment with different object origins and pivots (10 min).
✅ Research other useful Blender modifiers (5 min).


---

### Day 10: Materials & Textures
## Topics:
- Adding materials to objects.
- Applying textures to objects.
- Understanding material properties.

🎯 Tasks:
✅ Add different materials to your created objects (15 min each).
✅ Apply textures to your objects (15 min each).
✅ Experiment with material properties (e.g., roughness, metallic) (10 min).
✅ Research different types of textures (e.g., diffuse, normal) (5 min).
✅ Create a simple scene with multiple objects and materials (15 min).


---

### Day 11: UV Mapping & Exporting
## Topics:
- Unwrapping UVs for texture application.
- Exporting 3D models in different formats (FBX, OBJ).
- Preparing models for use in Unity.

🎯 Tasks:
✅ Unwrap the UVs of a simple object (15 min).
✅ Apply a texture to the UV unwrapped object (15 min).
✅ Export your model in FBX and OBJ formats (10 min each).
✅ Research best practices for exporting 3D models (5 min).
✅ Practice exporting various objects with different settings (15 min).


---

### Day 12:  Blender Practice Project
## Topics:
- Creating a simple scene in Blender.
- Applying learned skills to a larger project.

🎯 Tasks:
✅ Create a simple environment (e.g., a room) (20 min).
✅ Model and texture a simple object (e.g., a chair) (20 min).
✅ Position and light the scene (10 min).
✅ Render an image of your scene (10 min).
✅ Explore online Blender tutorials for inspiration (5 min).

---

### Day 13: Spatial Reasoning Exercises
## Topics:
- Mental rotation of 3D objects.
- Visualizing objects in 3D space.
- Understanding perspective and depth.

🎯 Tasks:
✅ Solve online spatial reasoning puzzles (20 min).
✅ Practice mentally rotating objects in your mind (15 min).
✅ Draw a 3D object from different perspectives (15 min).
✅ Try visualizing a simple scene in 3D space (10 min).
✅ Research techniques for improving spatial reasoning (5 min).


---

### Day 14: BLANK


---

### Day 15: Introduction to Unity
## Topics:
- Unity interface and project setup.
- Creating a new project.
- Navigating the Unity editor.

🎯 Tasks:
✅ Download and install Unity (15 min).
✅ Create a new Unity project (10 min).
✅ Explore the Unity interface and its different panels (15 min).
✅ Watch a Unity tutorial on interface navigation (15 min).
✅ Research Unity's different features (5 min).


---

### Day 16: Game Objects & Components
## Topics:
- Creating and manipulating game objects.
- Understanding different components (Transform, Mesh Renderer, etc.).
- Hierarchy and parenting.

🎯 Tasks:
✅ Create various game objects (cubes, spheres) in your Unity project (15 min).
✅ Add and modify components to the game objects (15 min).
✅ Experiment with parenting and hierarchy (15 min).
✅ Practice moving, rotating and scaling objects using the transform component (10 min).
✅ Research different Unity components (5 min).


---

### Day 17:  Scripting in C# (Basics)
## Topics:
- Writing basic C# scripts in Unity.
- Understanding variables, data types, and functions.
- Attaching scripts to game objects.

🎯 Tasks:
✅ Watch a tutorial on basic C# scripting (20 min).
✅ Create a simple C# script that prints a message to the console (15 min).
✅ Create a C# script to change the color of a game object (15 min).
✅ Learn about different data types in C# (10 min).
✅ Research different ways to debug C# scripts (5 min).


---

### Day 18: Scene Management
## Topics:
- Creating and managing scenes.
- Switching between scenes.
- Understanding scene organization.

🎯 Tasks:
✅ Create two separate scenes in Unity (15 min).
✅ Add game objects to each scene (10 min each).
✅ Write a script to switch between your two scenes (15 min).
✅ Practice managing a larger project with multiple scenes (10 min).
✅ Research different approaches to scene management (5 min).


---

### Day 19: Asset Importing & Management
## Topics:
- Importing 3D models and textures into Unity.
- Organizing assets in the project.
- Understanding asset import settings.

🎯 Tasks:
✅ Import your Blender model into Unity (15 min).
✅ Import textures for your model (15 min).
✅ Organize assets into folders in your project (10 min).
✅ Experiment with different asset import settings (10 min).
✅ Research best practices for asset management (5 min).


---

### Day 20: Basic UI Design
## Topics:
- Creating user interfaces (UI) in Unity.
- Using UI elements (buttons, text, images).
- Layering and arranging UI elements.

🎯 Tasks:
✅ Create a simple UI with a button and text (15 min).
✅ Add functionality to your button (e.g., switching scenes) (15 min).
✅ Experiment with different UI layouts and arrangements (10 min).
✅ Research different UI elements and their properties (5 min).
✅ Create a more complex UI with multiple elements (15 min).


---

### Day 21: BLANK


---

### Day 22: Introduction to ARKit/ARCore
## Topics:
- Choosing between ARKit and ARCore.
- Setting up development environment for chosen SDK.
- Understanding the basics of AR tracking.

🎯 Tasks:
✅ Research ARKit and ARCore, choose one (10 min).
✅ Set up development environment for selected SDK (15 min).
✅ Watch tutorial on basic AR tracking (15 min).
✅ Read documentation on plane detection (10 min).
✅ Research common issues and troubleshooting (5 min).


---

### Day 23: Plane Detection & Object Placement
## Topics:
- Detecting planes in the real world.
- Placing 3D objects on detected planes.
- Handling plane detection events.

🎯 Tasks:
✅ Create a simple scene with plane detection (20 min).
✅ Place your 3D model onto a detected plane (20 min).
✅ Handle events related to plane detection (e.g., plane added, plane removed) (10 min).
✅ Experiment with different plane detection methods (5 min).
✅ Implement error handling for plane detection (5 min).


---

### Day 24: AR Interaction (Touch Input)
## Topics:
- Implementing touch input for object manipulation.
- Moving, rotating, and scaling objects using touch gestures.
- Handling touch events.

🎯 Tasks:
✅ Implement touch input to move your object (20 min).
✅ Implement touch input to rotate your object (20 min).
✅ Implement touch input to scale your object (10 min).
✅ Test and improve your touch input implementation (5 min).
✅ Research alternative interaction methods (5 min).


---

### Day 25:  AR Project – Simple AR App
## Topics:
- Building a small functional AR application.
- Consolidating learning from previous days.

🎯 Tasks:
✅ Design a simple AR application (15 min).
✅ Implement core functionality of your chosen AR app (20 min).
✅ Test and debug your AR application (15 min).
✅ Add basic UI elements to your AR app (10 min).
✅ Document your project (5 min).


---

### Day 26: Introduction to Git
## Topics:
- Setting up a Git repository.
- Basic Git commands (init, add, commit, push, pull).
- Using a remote repository (GitHub, GitLab).

🎯 Tasks:
✅ Install Git and create a GitHub account (15 min).
✅ Initialize a local Git repository (10 min).
✅ Add, commit, and push your AR project to GitHub (20 min).
✅ Research different Git branching strategies (5 min).
✅ Practice basic Git commands using a simple project (10 min).


---

### Day 27: Image Editing for AR (Photoshop/GIMP)
## Topics:
- Basic image editing for textures.
- Optimizing images for AR (size, format, compression).
- Creating simple textures.

🎯 Tasks:
✅ Choose an image editing software (Photoshop/GIMP) (5 min).
✅ Create a simple texture using your chosen software (20 min).
✅ Optimize the texture for AR (size, format, compression) (15 min).
✅ Experiment with different image editing techniques (10 min).
✅ Research best practices for creating AR textures (5 min).


---

### Day 28: BLANK


---

### Day 29: AR Project Enhancement & Optimization
## Topics:
- Improving the performance of your AR application.
- Adding more features and interactivity.

🎯 Tasks:
✅ Profile and identify performance bottlenecks in your AR application (15 min).
✅ Optimize your 3D models and textures (15 min).
✅ Add more features or interactions to enhance the user experience (15 min).
✅ Retest and refine your AR application (10 min).
✅ Research AR optimization techniques (5 min).


---

### Day 30: BLANK

